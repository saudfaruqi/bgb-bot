#!/usr/bin/env bash
#
# ElectraLink portal app — one-shot droplet installer (Ubuntu 22.04 / 24.04)
#
# Run as root from inside the unpacked bundle directory:
#     bash setup.sh
#
# Options:
#     --domain app.example.com     configure nginx server_name + Let's Encrypt TLS
#     --auth-user NAME             HTTP basic-auth username (default: admin)
#     --auth-pass SECRET           HTTP basic-auth password (default: generated)
#     --workers N                  CONCURRENT_WORKERS in .env (default: sized from RAM)
#     --no-firewall                skip ufw configuration
#
# Idempotent: safe to re-run after a code update (it re-syncs, reinstalls deps,
# and restarts the service without touching .env, credentials.json or the DB).

set -euo pipefail

APP_NAME="electralink"
APP_DIR="/opt/${APP_NAME}"
APP_USER="${APP_NAME}"
SERVICE="${APP_NAME}"
PORT="8000"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DOMAIN=""
AUTH_USER="admin"
AUTH_PASS=""
WORKERS=""
DO_FIREWALL=1

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain)      DOMAIN="$2"; shift 2 ;;
    --auth-user)   AUTH_USER="$2"; shift 2 ;;
    --auth-pass)   AUTH_PASS="$2"; shift 2 ;;
    --workers)     WORKERS="$2"; shift 2 ;;
    --no-firewall) DO_FIREWALL=0; shift ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "ERROR: run this as root (sudo bash setup.sh)" >&2
  exit 1
fi

log() { printf '\n\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*"; }

TOTAL_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
if [[ -z "$WORKERS" ]]; then
  if   [[ "$TOTAL_MB" -ge 7500 ]]; then WORKERS=8
  elif [[ "$TOTAL_MB" -ge 3500 ]]; then WORKERS=5
  elif [[ "$TOTAL_MB" -ge 1800 ]]; then WORKERS=3
  else WORKERS=2
  fi
fi
log "Detected ${TOTAL_MB}MB RAM — CONCURRENT_WORKERS=${WORKERS}"
if [[ "$TOTAL_MB" -lt 3500 ]]; then
  warn "Chromium is memory-hungry. 4GB+ is recommended for this app; swap will be added below."
fi

# ---------------------------------------------------------------- packages ---
log "Installing system packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq \
  python3 python3-venv python3-pip \
  nginx apache2-utils \
  curl ca-certificates rsync unzip \
  sqlite3

# ------------------------------------------------------------------- swap ---
if ! swapon --show | grep -q .; then
  log "Creating 4GB swap file (none present)"
  fallocate -l 4G /swapfile
  chmod 600 /swapfile
  mkswap -q /swapfile
  swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  sysctl -q -w vm.swappiness=10
  grep -q '^vm.swappiness' /etc/sysctl.conf || echo 'vm.swappiness=10' >> /etc/sysctl.conf
else
  log "Swap already configured — skipping"
fi

# --------------------------------------------------------------- app user ---
if ! id -u "$APP_USER" >/dev/null 2>&1; then
  log "Creating service user '${APP_USER}'"
  useradd --system --create-home --home-dir "/home/${APP_USER}" --shell /usr/sbin/nologin "$APP_USER"
fi

# ------------------------------------------------------------------- code ---
log "Syncing application code to ${APP_DIR}"
mkdir -p "$APP_DIR"
rsync -a --delete \
  --exclude '.venv' \
  --exclude 'analytics.db' \
  --exclude 'credentials.json' \
  --exclude '.env' \
  --exclude 'uploads' --exclude 'outputs' --exclude 'state' --exclude 'job_meta' \
  --exclude 'setup.sh' \
  "$SRC_DIR"/ "$APP_DIR"/

mkdir -p "$APP_DIR"/{uploads,outputs,state,job_meta}
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

# ------------------------------------------------------------------- venv ---
log "Building Python virtualenv and installing dependencies"
if [[ ! -d "$APP_DIR/.venv" ]]; then
  sudo -u "$APP_USER" python3 -m venv "$APP_DIR/.venv"
fi
sudo -u "$APP_USER" "$APP_DIR/.venv/bin/pip" install --quiet --upgrade pip wheel
sudo -u "$APP_USER" "$APP_DIR/.venv/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"

log "Installing Chromium for Playwright (this pulls ~400MB, be patient)"
"$APP_DIR/.venv/bin/playwright" install-deps chromium
sudo -u "$APP_USER" env HOME="/home/${APP_USER}" "$APP_DIR/.venv/bin/playwright" install chromium

# -------------------------------------------------------------------- env ---
if [[ ! -f "$APP_DIR/.env" ]]; then
  log "Writing ${APP_DIR}/.env (fill in PORTAL_USER / PORTAL_PASS)"
  cat > "$APP_DIR/.env" <<EOF
# ElectraLink portal credentials — required for jobs to run.
# You can also set these from the dashboard's credentials panel, which
# writes ${APP_DIR}/credentials.json and takes precedence over this file.
PORTAL_USER=
PORTAL_PASS=

# MUST stay true on a server — there is no display.
BROWSER_HEADLESS=true

# Concurrency and timing (sized for this droplet)
CONCURRENT_WORKERS=${WORKERS}
METER_RETRIES=2
BACKOFF_BASE=0.5
INCREMENTAL_SAVE_EVERY=25
MAX_JOB_RETRIES=1
RETRY_DELAY_SECONDS=10
STUCK_TIMEOUT_SECONDS=15
PAGE_LOAD_TIMEOUT=1200
HEARTBEAT_TIMEOUT=20
HEARTBEAT_INTERVAL=15
CONNECTION_RETRY_ATTEMPTS=2
EOF
  chown "$APP_USER":"$APP_USER" "$APP_DIR/.env"
  chmod 600 "$APP_DIR/.env"
else
  log ".env already exists — leaving it untouched"
fi

# ----------------------------------------------------------------- systemd ---
log "Installing systemd unit /etc/systemd/system/${SERVICE}.service"
cat > "/etc/systemd/system/${SERVICE}.service" <<EOF
[Unit]
Description=ElectraLink meter portal (FastAPI + Playwright)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${APP_USER}
Group=${APP_USER}
WorkingDirectory=${APP_DIR}
Environment=HOME=/home/${APP_USER}
Environment=PYTHONUNBUFFERED=1
EnvironmentFile=${APP_DIR}/.env
ExecStart=${APP_DIR}/.venv/bin/python -m uvicorn app_async:app --host 127.0.0.1 --port ${PORT} --timeout-keep-alive 120
Restart=always
RestartSec=5
KillSignal=SIGINT
TimeoutStopSec=30
LimitNOFILE=65535

# Chromium needs a writable /tmp and shared memory; keep hardening light.
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --quiet "$SERVICE"

# ------------------------------------------------------------- basic auth ---
if [[ ! -f /etc/nginx/.htpasswd ]]; then
  if [[ -z "$AUTH_PASS" ]]; then
    AUTH_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 18)"
  fi
  htpasswd -bc /etc/nginx/.htpasswd "$AUTH_USER" "$AUTH_PASS" >/dev/null 2>&1
  chmod 640 /etc/nginx/.htpasswd
  chown root:www-data /etc/nginx/.htpasswd
  CREATED_AUTH=1
else
  log "/etc/nginx/.htpasswd exists — keeping existing login"
  CREATED_AUTH=0
fi

# ------------------------------------------------------------------ nginx ---
log "Configuring nginx reverse proxy"
SERVER_NAME="${DOMAIN:-_}"
cat > "/etc/nginx/sites-available/${APP_NAME}" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${SERVER_NAME};

    # Spreadsheet uploads can be large.
    client_max_body_size 512M;
    client_body_timeout 300s;

    access_log /var/log/nginx/${APP_NAME}.access.log;
    error_log  /var/log/nginx/${APP_NAME}.error.log;

    location / {
        auth_basic "ElectraLink";
        auth_basic_user_file /etc/nginx/.htpasswd;

        proxy_pass http://127.0.0.1:${PORT};
        proxy_http_version 1.1;

        # WebSocket live job feed (/ws/{job_id})
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;

        # Scrape jobs run for hours — do not cut the connection.
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_connect_timeout 60s;
        proxy_buffering off;
    }
}
EOF

ln -sf "/etc/nginx/sites-available/${APP_NAME}" "/etc/nginx/sites-enabled/${APP_NAME}"
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

# --------------------------------------------------------------- firewall ---
if [[ "$DO_FIREWALL" -eq 1 ]] && command -v ufw >/dev/null 2>&1; then
  log "Configuring ufw (SSH + HTTP/HTTPS)"
  ufw allow OpenSSH >/dev/null
  ufw allow 'Nginx Full' >/dev/null
  ufw --force enable >/dev/null
fi

# -------------------------------------------------------------------- TLS ---
if [[ -n "$DOMAIN" ]]; then
  log "Requesting Let's Encrypt certificate for ${DOMAIN}"
  apt-get install -y -qq certbot python3-certbot-nginx
  certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
    --register-unsafely-without-email --redirect || \
    warn "certbot failed — check that ${DOMAIN}'s A record points at this droplet, then re-run: certbot --nginx -d ${DOMAIN}"
fi

# ------------------------------------------------------------------ start ---
log "Starting ${SERVICE}"
systemctl restart "$SERVICE"
sleep 4

if systemctl is-active --quiet "$SERVICE"; then
  log "Service is running"
else
  warn "Service failed to start. Last 40 log lines:"
  journalctl -u "$SERVICE" -n 40 --no-pager || true
  exit 1
fi

IP="$(curl -s --max-time 5 ifconfig.me || hostname -I | awk '{print $1}')"
URL="http://${DOMAIN:-$IP}"
[[ -n "$DOMAIN" ]] && URL="https://${DOMAIN}"

cat <<EOF

────────────────────────────────────────────────────────────────
 ElectraLink is deployed.

   URL         ${URL}
   App dir     ${APP_DIR}
   Service     systemctl status ${SERVICE}
   Logs        journalctl -u ${SERVICE} -f
   Env file    ${APP_DIR}/.env   (PORTAL_USER / PORTAL_PASS)
   Database    ${APP_DIR}/analytics.db  (created fresh on first run)
EOF

if [[ "${CREATED_AUTH}" -eq 1 ]]; then
cat <<EOF

   Browser login (HTTP basic auth) — save these now:
     user      ${AUTH_USER}
     password  ${AUTH_PASS}
EOF
fi

cat <<EOF

 NEXT STEP: put your portal credentials in ${APP_DIR}/.env, then
   systemctl restart ${SERVICE}
 (or enter them in the dashboard's credentials panel instead).
────────────────────────────────────────────────────────────────

EOF
